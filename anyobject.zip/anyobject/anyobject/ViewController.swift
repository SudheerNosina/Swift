//
//  ViewController.swift
//  anyobject
//
//  Created by Naveen Gundu on 10/09/17.
//  Copyright © 2017 NSP. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var check = [String]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let value = checkMyObject(check as AnyObject)
        
        print(value)
    }

    //Function for find Object is which category
    func checkMyObject(_ object: AnyObject) -> AnyObject{
        
        if object is Dictionary<String,Any>{
            
            print("Your object is Dictionary")
            return object
            
        }else if object is [Any]{
            
            print("Your object is Array")
            return object
            
        }else if object is String{
            
            print("Your object is String")
            return object
            
        }else if object is Int{
            
            print("Your object is Int")
            return object
            
        }else if object is Double{
            
            print("Your object is Double")
            return object
            
        }else if object is NSNull{
            
            print("Your object is Null")
            return object
            
        }else{
            print("Your object is Something")
            return object
        }
            
    }

}

