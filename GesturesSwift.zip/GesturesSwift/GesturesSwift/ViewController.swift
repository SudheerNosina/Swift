//
//  ViewController.swift
//  GesturesSwift
//
//  Created by Naveen Gundu on 30/10/17.
//  Copyright © 2017 NSP. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var viewDrag: UIView!
    
    var pinchGesture = UIPinchGestureRecognizer()
    var panGesture = UIPanGestureRecognizer()
    var longGesture = UILongPressGestureRecognizer()
    var tapGesture = UITapGestureRecognizer()
    var swipeGesture  = UISwipeGestureRecognizer()
    var rotateGesture  = UIRotationGestureRecognizer()
    
    var lastRotation   = CGFloat()
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        
        viewDrag.backgroundColor = .red
        viewDrag.isUserInteractionEnabled = true
        
        //MARK: PanGestureRecognizer
        panGesture = UIPanGestureRecognizer(target: self, action: #selector(self.draggedView(_:)))
        viewDrag.addGestureRecognizer(panGesture)

        //MARK: PinchGestureRecognizer
        pinchGesture = UIPinchGestureRecognizer(target: self,action: #selector(self.pinchedView))
        viewDrag.addGestureRecognizer(pinchGesture)
        
        
        //MARK: RotationalGestureRecognizer
        rotateGesture = UIRotationGestureRecognizer(target: self, action: #selector(ViewController.rotatedView(_:)))
        viewDrag.addGestureRecognizer(rotateGesture)
        viewDrag.isMultipleTouchEnabled = true
        
        //MARK: TapGestureRecognizer
        tapGesture = UITapGestureRecognizer(target: self, action: #selector(ViewController.myviewTapped(_:)))
        tapGesture.numberOfTapsRequired = 1
        tapGesture.numberOfTouchesRequired = 1
        viewDrag.addGestureRecognizer(tapGesture)
        
        
        //MARK: SwipeGestureRecognizer
        let directions: [UISwipeGestureRecognizerDirection] = [.up, .down, .right, .left]
       
        for direction in directions {
            swipeGesture = UISwipeGestureRecognizer(target: self, action: #selector(ViewController.swipwView(_:)))
            viewDrag.addGestureRecognizer(swipeGesture)
            swipeGesture.direction = direction
            //viewDrag.isUserInteractionEnabled = true
            viewDrag.isMultipleTouchEnabled = true
        }
        
        //MARK: LongGestureRecognizer
        longGesture = UILongPressGestureRecognizer(target: self, action: #selector(ViewController.longPress(_:)))
        longGesture.minimumPressDuration = 1
        viewDrag.addGestureRecognizer(longGesture)
        
        
    }
    
    //MARK: PinchGestureRecognizerFunction
    func pinchedView(sender:UIPinchGestureRecognizer){
        
        self.view.bringSubview(toFront: viewDrag)
        
        sender.view?.transform = (sender.view?.transform)!.scaledBy(x: sender.scale, y: sender.scale)
        sender.scale = 1.0
    }
    
    //MARK: PanGestureRecognizerFunction
    @objc func draggedView(_ sender: UIPanGestureRecognizer){
     
     self.view.bringSubview(toFront: viewDrag)
     
     let translation = sender.translation(in: self.view)
     
     viewDrag.center = CGPoint(x: viewDrag.center.x + translation.x, y: viewDrag.center.y + translation.y)
     
     sender.setTranslation(CGPoint.zero, in: self.view)
     }

    //MARK: RotationalGestureRecognizerFunction
    func rotatedView(_ sender : UIRotationGestureRecognizer){
        
        var lastRotation = CGFloat()
        
        self.view.bringSubview(toFront: viewDrag)
        
        if(sender.state == UIGestureRecognizerState.ended){
            lastRotation = 0.0;
        }
        
        let rotation = 0.0 - (lastRotation - sender.rotation)
        // var point = rotateGesture.location(in: viewRotate)
        
        let currentTrans = sender.view?.transform
        
        let newTrans = currentTrans!.rotated(by: rotation)
        
        sender.view?.transform = newTrans
        
        lastRotation = sender.rotation
    }
    
    //MARK: TapGestureRecognizerFunction
    func myviewTapped(_ sender: UITapGestureRecognizer) {
        
        if self.viewDrag.backgroundColor == UIColor.yellow {
            self.viewDrag.backgroundColor = UIColor.green
        }else{
            self.viewDrag.backgroundColor = UIColor.yellow
        }
    }
    
    //MARK: SwipeGestureRecognizerFunction
    func swipwView(_ sender : UISwipeGestureRecognizer){
        
        UIView.animate(withDuration: 1.0) {
        
            if sender.direction == .right {
            
                self.viewDrag.frame = CGRect(x: self.view.frame.size.width - self.viewDrag.frame.size.width, y: self.viewDrag.frame.origin.y , width: self.viewDrag.frame.size.width, height: self.viewDrag.frame.size.height)
            
            }else if sender.direction == .left{
                
                self.viewDrag.frame = CGRect(x: 0, y: self.viewDrag.frame.origin.y , width:
                self.viewDrag.frame.size.width, height: self.viewDrag.frame.size.height)
                
            }else if sender.direction == .up{
                
                self.viewDrag.frame = CGRect(x: self.view.frame.size.width - self.viewDrag.frame.size.width, y: 0 , width: self.viewDrag.frame.size.width, height: self.viewDrag.frame.size.height)
            
            }else if sender.direction == .down{
            
                self.viewDrag.frame = CGRect(x: self.view.frame.size.width - self.viewDrag.frame.size.width, y: self.view.frame.size.height - self.viewDrag.frame.height , width: self.viewDrag.frame.size.width, height: self.viewDrag.frame.size.height)
            
            }
            
            self.viewDrag.layoutIfNeeded()
            self.viewDrag.setNeedsDisplay()
        }
    }
    
    //MARK: LongGestureRecognizer
    func longPress(_ sender: UILongPressGestureRecognizer) {
        let alertC = UIAlertController(title: "Long Press", message: "Long press gesture called when you press on view of 1 second duration.", preferredStyle: UIAlertControllerStyle.alert)
        let ok = UIAlertAction(title: "OK", style: UIAlertActionStyle.default) { (alert) in
        }
        alertC.addAction(ok)
        self.present(alertC, animated: true, completion: nil)
    }
    
}

