//
//  ViewController.swift
//  sudheerNewJSON
//
//  Created by Naveen Gundu on 12/09/17.
//  Copyright © 2017 NSP. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    
    //MARK: GET JSON Process
    
    @IBAction func getButton(_ sender: Any) {
        
        let parameters = ["MyName":"Nosina","MySound":"Kickck"]
        guard let url = URL(string:"https://jsonplaceholder.typicode.com/users")else{return}
        
        var request = URLRequest(url: url)
        
        guard let body = try? JSONSerialization.data(withJSONObject: parameters, options: [])
            else {return}
        request.httpMethod = "GET"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = body
        
        
        let session = URLSession.shared.dataTask(with: url, completionHandler: {(data, response,error) in
            
            if error != nil{
                print(error ?? "")
            }else{
                do{
                    let json = try JSONSerialization.jsonObject(with: data!, options: [])
                    print(json)
                }catch{
                    print(error)
                }
            }
            
        })
        session.resume()
        
    }
    
    //MARK: POST JSON Proocess
    @IBAction func postButton(_ sender: Any){
        
        let parameters = ["username":"sudheer","tweet":"Mytweet"]
        
        guard let url = URL(string: "https://jsonplaceholder.typicode.com/posts")else{return}
        
        var request = URLRequest(url: url)
        
        request.httpMethod = "POST"
        
        guard let httpbody = try? JSONSerialization.data(withJSONObject: parameters, options: [])else{return}
        
        request.httpBody = httpbody
        
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        
        let session = URLSession.shared.dataTask(with: request, completionHandler: {(data,response,error) in
            
            if let response = response{
                
                print(response)
            }
            if error != nil{
                
                print(error ?? "")
                
            }else{
                
                do{
                    let json = try JSONSerialization.jsonObject(with: data!, options: [])
                    print(json)
                    
                }catch{
                    
                    print(error)
                }
            }
            
        })
        session.resume()
        
    }
    

    //MARK: PUT JSON Process
    
    @IBAction func putButton(_ sender: Any) {
        
        let parameters = ["MyName":"Nosina","MySound":"Kickck"]
        
        guard let url = URL(string: "https://jsonplaceholder.typicode.com/posts/1") else {return}
        
        var request = URLRequest(url: url)
        
        guard let body = try? JSONSerialization.data(withJSONObject: parameters, options: [])
            else {return}
        
        request.httpMethod = "PUT"
        
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        
        request.httpBody = body
        
        let task = URLSession.shared.dataTask(with: request, completionHandler: {(data,response,error) in
            
            if let respo = response{
                
                print(respo)
            }
            if error != nil{
                
                print(error ?? "")
                
            }else{
                
                do{
                    let json = try JSONSerialization.jsonObject(with: data!, options: [])
                    print(json)
                    
                }catch{
                    
                    print(error)
                }
            }
        })
        
        task.resume()
    }

    
    //MARK: DELETE JSON Process
    @IBAction func deleteButton(_ sender: Any) {
        
        let parameters = ["animal":"Cow","Tree":"COconutTree"]
        
        guard let url = URL(string: "https://jsonplaceholder.typicode.com/posts/1") else {return}
        
        var request = URLRequest(url:url)
        
        request.httpMethod = "DELETE"
        
        guard let httpBody = try? JSONSerialization.data(withJSONObject: parameters, options: [])else{return}
        
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        
        request.httpBody = httpBody
        
        let session = URLSession.shared.dataTask(with: request, completionHandler: {(data,response,error) in
            
            if let respo = response{
                
                print(respo)
            }
            if error != nil{
                
                print(error ?? "")
                
            }else{
                
                do{
                    let json = try JSONSerialization.jsonObject(with: data!, options: [])
                    print(json)
                    
                }catch{
                    
                    print(error)
                }
            }
            
        })
        session.resume()
    }
}



















